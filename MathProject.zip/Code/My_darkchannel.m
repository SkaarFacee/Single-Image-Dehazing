%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    My_darkchannel��Seeking dark channel
%   Input��
%       I��Input RGB image
%       window_size��The window size of the dark channel minimum filter
%   Output��Dark channel
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [output] = My_darkchannel(I,window_size)

    %% The first step is to read image information
	% Get image size and dimensions
    [height,width,~] = size(I);
    % Initialize the dark channel image
    dark_channel = ones(height,width);
    
    %% Step 2: Get the minimum value of the three channels for each pixel
    for i = 1:height
        for j = 1:width
            % Get the minimum value of the three channels at the pixel position
            dark_channel(i,j) = min( I(i,j,:) );
 
        end
    end 
    
    %% The third step minimum filter
    % Call My_minfilter function for minimum filtering
    min_dark_channel = My_minfilter(dark_channel,window_size);
    
    %% Step 4 Output dark channel
    output = min_dark_channel;
    
end