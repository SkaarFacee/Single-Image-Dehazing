%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    My_estimateA��Estimated global atmospheric light A
%   Input��
%       I��Input RGB image
%       dark_channel��I�İ�ͨ��
%   Output��Global atmospheric light A of RGB three channels
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [output] = My_estimateA(I,dark_channel)
    
    %% The first step is to initialize A and read the information
    A = zeros(1,1,3);
    [height,width] = size(dark_channel);
    
   
    
    % The total number of points to be taken (a total of points before 0.1% of the brightness value)
    points_number = round(width * height * 0.001);
    % Calculate the value of A from the brightest point below
    % Iteration
    for k = 1:points_number    
        
         %% Step 2 Take out the bright spots in dark_channel
        brightest_points = max( max(dark_channel) );
        [i,j] = find (dark_channel==brightest_points);
        % There may be multiple highlights, just pick the first one
        i = i(1);
        j = j(1);
        % Set this brightest point to 0, which is convenient to find the second brightest point
        dark_channel(i,j) = 0;
        
         %% The third step is to calculate the A value according to the position of the bright spot
        % Find its brightness value at the corresponding position in the original image
        %Average the three channels 	
        % If it is greater than A, update the value of A
        if(mean( I(i,j,:) )>mean(A(1,1,:)))
            % Record the A value of the three channels separately
            A(1,1,1) = (A(1,1,1)+I(i,j,1))/2;
            A(1,1,2) = (A(1,1,2)+I(i,j,2))/2;
            A(1,1,3) = (A(1,1,3)+I(i,j,3))/2;
        end
    end
    
    %% Step 4 output A
    output = A;
end