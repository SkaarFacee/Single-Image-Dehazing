%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   My_guidedfilter��Guided filtering to optimize the projection rate matrix
%   Input��
%       guide_image��Wizard picture
%       I��Filter picture
%       radius��Filter radius
%       sooth_parameter��Smoothness
%   Output��Optimized projection rate matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [output] = My_guidedfilter(guide_image, I, radius, sooth_parameter)


    [height, width] = size(guide_image);
    % The cumulative sum of radius in the projection rate matrix, easy to average
    N = My_cumulative_sum(ones(height, width), radius); 
    
    % Average of the guide graph
    mean_guide = My_cumulative_sum(guide_image, radius) ./ N;
    % Average of the filtered image
    mean_I = My_cumulative_sum(I, radius) ./ N;
    % Calculate the average of the product of the guide graph and the filtered graph
    mean_IG = My_cumulative_sum(guide_image.*I, radius) ./ N;
    % Calculate the covariance of the guide graph and the filtered graph
    cov_IG = mean_IG - mean_guide .* mean_I;
    % Calculate the average of the square of the wizard graph
    mean_II = My_cumulative_sum(guide_image.*guide_image, radius) ./ N;
    % Calculate the variance of the filtered image
    var_I = mean_II - mean_guide .* mean_guide;
    
    % Find a
    a = cov_IG ./ (var_I + sooth_parameter);
    % Find b
    b = mean_I - a .* mean_guide; 
    
    % Find the average of a
    mean_a = My_cumulative_sum(a, radius) ./ N;
    % Find the average of b
    mean_b = My_cumulative_sum(b, radius) ./ N;
    
    % Build q
    q = mean_a .* guide_image + mean_b; 
    output = q;
end