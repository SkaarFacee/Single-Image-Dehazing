%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    My_minfilter��Function
%   Input��
%       I��Input grayscale image
%       window_size��Window size for minimum filtering
%   Output��output��Dark channel image with minimum filter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [output] = My_minfilter(I,window_size)

    %% The first step is to read image information
    I_new = I;
    [height,width] = size(I);
    
    %% The second step is to traverse the loop to minimize
    for i = 1:height
        for j = 1:width
            % Handling boundaries to prevent crossing boundaries
            i_down = i-window_size;
            i_up = i+window_size;
            j_down = j-window_size;
            j_up = j+window_size;
            if(i_down<=0)
                i_down = 1;
            end
            if(j_down<=0)
                j_down = 1;
            end
            if(i_up>height)
                i_up = height;
            end
            if(j_up>width)
                j_up = width;
            end
            % Minimum filtering, taking the minimum value in the window as the value of the current pixel
            I_new(i,j) =  min (min(I(i_down:i_up,j_down:j_up)) );
        end
    end
    
    %% The third step is to form output
    output = I_new;
end