%% Robustness test-dark channel prior defogging algorithm based on tolerance
tic
%% The first step is to read the image and get the basic information of the size
clear;     
clc;       
for image_number=1:30
    disp(1);
    imageName=strcat(num2str(image_number),'.jpg');
    I = imread(imageName);
    %figure;
    %imshow(I,[]);
    %title(['First',num2str(image_number),'Original image']);

    % Get image size and dimensions
    [height,width,dimention] = size(I);

    %% The second step is to obtain the dark channel image
    disp(2);
    window_size = 7;
    % Call the My_darkchannel function
    dark_channel =  My_darkchannel(I,window_size);
    dark_channel = dark_channel./255;

    %% The third step is to calculate the atmospheric light component A
    % A is a 1*1*3 matrix, that is, three RGB lighting components are extracted
    disp(3);
    I = im2double(I);
    % Call the My_estimateA function
    A = My_estimateA(I,dark_channel);

    %% Calculate the transmittance matrix t(x)
    disp(4);
    % Complete dehazing coefficient, w = 1 complete dehazing
    w = 0.95;

    % Use dark channel to estimate transmittance 
    t = 1-w*dark_channel/mean(A(1,1,:));

    % Get grayscale picture
    I_gray = rgb2gray(I);

    % Use guided filtering to optimize t
    % Call My_guidedfilter function to soft map to optimize transmittance matrix
    t1 = My_guidedfilter(I_gray, t, 135, 0.0002);

    % Projection rate matrix
    % Edge blur
    t2 = My_guidedfilter(t1,t1,7,0.03);

    % Transmission image threshold to prevent the image pixel value from being too large when the projection image is small
    t_treshold = 0.1;
    % Take t0=0.1 to prevent the overall transition to white field, and take 0.1 for values �6¤7�6¤7less than 0.1

    t = max(t2,t_treshold);


    %% Step 4 Restore the fog-free image
    disp(5);
    % Introduce tolerance
    K = 0.2;
    % Initialize defogging image
    defog_image = zeros(size(I));

    % Use the improved formula to divide three channels for defogging
    defog_image(:,:,1) = ((I(:,:,1)-A(1,1,1))...
                            ./min(1,t.*max( K./abs(I(:,:,1)-A(1,1,1)),1) ...
                            )) +A(1,1,1);
    defog_image(:,:,2) = ((I(:,:,2)-A(1,1,2))...
                            ./min(1,t.*max( K./abs(I(:,:,2)-A(1,1,2)),1) ...
                            )) +A(1,1,2);

    defog_image(:,:,3) = ((I(:,:,3)-A(1,1,3))...
                            ./min(1, t.*max( K./abs(I(:,:,3)-A(1,1,3)),1) ...
                            )) +A(1,1,3);


    % dark channel prior method will darken the picture
    % Multiplication factor makes the picture bright
    defog_image = defog_image*1.3;

    %% Step 5 Output fog-free image
    disp(6);
    %figure;
    %imshow(defog_image);
    str1='new'
    str2=strcat(num2str(image_number),'.jpg')
    str=append(str1,str2)
    imwrite(defog_image,str)
    %title(['First',num2str(image_number),'Dehazing image']);
    clc;
    clear;    
end
    toc

